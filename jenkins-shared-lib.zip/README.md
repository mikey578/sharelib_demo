# Jenkins Shared Library

Supports Java and PHP projects.
